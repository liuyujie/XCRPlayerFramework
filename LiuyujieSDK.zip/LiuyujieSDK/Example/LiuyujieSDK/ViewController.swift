//
//  ViewController.swift
//  LiuyujieSDK
//
//  Created by liuyujieemail@163.com on 03/19/2018.
//  Copyright (c) 2018 liuyujieemail@163.com. All rights reserved.
//

import UIKit
import LiuyujieSDK

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        let status = LiuyujieSDK().start()
        print(status)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

