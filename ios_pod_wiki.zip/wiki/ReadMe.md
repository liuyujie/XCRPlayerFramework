# 模块化组件打包集成方案

项目痛点：
iOS打包过慢

希望的解决方案：
	项目中直接引用已经打好包的第三方framework和自己的私有组件和模块这样就可以提高编译速度，此法集成后打包好的framework代码无法调试，
	

#### 1.通过 pod 创建私有库 
	
	pod lib create ProjectName
	
通过pod lib create创建一个pod,分析创建流程
当执行pod lib create ProjectName时,其实是下载了一个pod模板,然后在内部通过更改.podspec文件的配置定制化自己的pod,pod lib create ProjectName其实使用了默认参数,补全的话 pod lib create ProjectName --template-url=https://github.com/CocoaPods/pod-template.git

我们也可以自定义模板

	pod lib create ProjectName --template-url=你自己模板的URL


### 2.打包私有库为framework

开发和测试完成后,如何打包私有库呢？

用Carthage 打包 pod 项目导出静态库 

	carthage build --no-skip-current --platform iOS
	或者（上面只编译iOS平台）
	carthage build --no-skip-current


Carthage 是什么有什么优点

1. Carthage 类似于 CocoaPods，为用户管理第三方框架和依赖，但不会自动修改项目文件和生成配置
2. Carthage是去中心化的依赖管理工具，安装依赖时不需要去中心仓库获取 CocoaPods 所有依赖的索引，节省时间
3. Carthage 对项目无侵入性，Carthage 设计上也比较简单，利用的都是 Xcode 自身的功能，开发者在创建依赖时，相比 CocoaPods 也简单许多
4. Carthage 管理的依赖只需编译一次，项目干净编译时，不会再去重新编译依赖，节省时间，自动将第三方框架编程为 Dynamic framework( 动态库 )
5. Carthage 与 CocoaPods 无缝集成，一个项目能同时拥有 CocoaPods 和 Carthage

Carthage的缺点

1. 仅支持 iOS8 + ，它只支持框架，所以不能用来针对 iOS 8 以前的系统版本进行开发
2. 安装包的大小比用CocoaPods安装的包大
3. 支持的 Carthage 安装的第三方框架和依赖不如 CocoaPods 丰富
4. 无法在 Xcode debug时定位到源码


### 3.创建指向framework的私有库

修改 podspec 中的 s.source 和添加 s.ios.vendored_frameworks

改为 s.source = { :http => 'framework.zip下载地址' }

用HTTP方式下载代码支持的格式有：zip, tgz, bz2, txz 和 tar。

	spec.source = { :http => 'http://dev.d.com/sdk/WeChat_SDK.zip' }
	spec.ios.vendored_frameworks = 'Frameworks/MyFramework.framework'


用git代码库也可实现（Demo：XCRPlayer_Framework）。

[例子：XCRPlayer_Framework](https://github.com/liuyujie/XCRPlayerFramework.git)

#### 4.发布私有库

之前的开发和测试就绪后,就要准备发布私有库了.

首先要检测Podspec的正确性

	pod lib lint 或者 pod spec lint 
	
pod lib lint 不会连接网络,而是检查本地项目配置是否正确

pod spec lint 会读取线上的repo并检查相应的tag

第一次发布可能提示没有私有库地址 解决方案：（repo_name代指库索引的别名）

	pod repo add repo_name repo_git_URL

以后发布版本更新

	pod repo push repo_name pod_lib_name.podspec --verbose

### 下面UMCCommon的例子

	{
	  "name": "UMCCommon",
	  "version": "1.4.1internation",
	  "summary": "UMeng+ component SDK",
	  "description": "友盟+组件化SDK基础库UMCommon",
	  "homepage": "http://dev.umeng.com/sdk_integate/ios-integrate-guide/common",
	  "license": {
	    "type": "Copyright",
	    "text": "Copyright 2011 - 2018 umeng.com. All rights reserved.\n"
	  },
	  "authors": {
	    "UMeng": "support@umeng.com"
	  },
	  "source": {
	    "http": "http://umplus-sdk-download.oss-cn-shanghai.aliyuncs.com/iOS/UMCommon/UMCommon_internation_1.4.1.zip"
	  },
	  "platforms": {
	    "ios": "6.0"
	  },
	  "requires_arc": true,
	  "ios": {
	    "vendored_frameworks": "UMCommon.framework"
	  },
	  "libraries": [
	    "sqlite3",
	    "z"
	  ],
	  "frameworks": [
	    "CoreTelephony",
	    "SystemConfiguration"
	  ]
	}

## 可能遇到的问题解决方案记录

## Dependency "Example" has no shared framework schemes

*  打开Example下的对应示例工程的xxx.xcworkspace，用xcode打开
*  然后选中Manage Scheme

![error1](carth_ shared_error.png)

*  这个时候重新回到根目录下，执行

		carthage build --no-skip-current --platform iOS
		
便能方便的生成一个已经二进制化的Framework

## reason: image not found的解决方案

首先我们分析一下出现这种情况的原因，原因就是framework找不到镜像了，也就是在真机运行是没有找到对应的framework包，在网上找的一些办法将框架引用从Required 变为Optional ，根本就是治标不治本，等到运行到这个framework的代码是也会崩溃，我们需要做的是将这个framework拷贝到项目里面才行，这样才能从根本上解决问题，下面是我的解决方案：

![图片1](framework_ image_not_found_1.jpeg)

![图片2](framework_ image_not_found_2.jpeg)

按上图所示将你的framework给copy到你的项目中就行了，这样就从根本上解决了问题~~


### 相关文档推荐：

[持续集成 编译加速Cocoapods二进制化实践](https://testerhome.com/topics/11834)

[CocoaPods创建公有和私有Pod库方法总结](https://segmentfault.com/a/1190000007947371)

[持续集成 编译加速Cocoapods二进制化实践](https://testerhome.com/topics/11834)

[podspec 说明文档地址](https://guides.cocoapods.org/syntax/podspec.html)

[private-cocoapods guides](https://guides.cocoapods.org/making/private-cocoapods.html)

[using-pod-lib-create](https://guides.cocoapods.org/making/using-pod-lib-create.html)

[UMCCommon.podspec.json](https://github.com/CocoaPods/Specs/blob/f3002f42e6ac2fa673926f790c668eb856362572/Specs/d/b/6/UMCCommon/1.4.1internation/UMCCommon.podspec.json)

[https://www.aliyun.com/jiaocheng/358001.html](https://www.aliyun.com/jiaocheng/358001.html)

