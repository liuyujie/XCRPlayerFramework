import Foundation

open class LiuyujieSDK : NSObject {
    
    public override init() {
        super.init()
    }
    
    // MARK:liuyujie
    public func start() -> String {
        return "start"
    }
    
}


extension LiuyujieSDK{
    
    public func stop(){
        print("stop")
    }
    
}


