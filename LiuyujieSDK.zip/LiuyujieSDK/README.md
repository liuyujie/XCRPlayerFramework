# LiuyujieSDK

[![CI Status](http://img.shields.io/travis/liuyujieemail@163.com/LiuyujieSDK.svg?style=flat)](https://travis-ci.org/liuyujieemail@163.com/LiuyujieSDK)
[![Version](https://img.shields.io/cocoapods/v/LiuyujieSDK.svg?style=flat)](http://cocoapods.org/pods/LiuyujieSDK)
[![License](https://img.shields.io/cocoapods/l/LiuyujieSDK.svg?style=flat)](http://cocoapods.org/pods/LiuyujieSDK)
[![Platform](https://img.shields.io/cocoapods/p/LiuyujieSDK.svg?style=flat)](http://cocoapods.org/pods/LiuyujieSDK)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

LiuyujieSDK is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'LiuyujieSDK'
```

## Author

liuyujieemail@163.com, liu.yujie@xcar.com.cn

## License

LiuyujieSDK is available under the MIT license. See the LICENSE file for more info.
