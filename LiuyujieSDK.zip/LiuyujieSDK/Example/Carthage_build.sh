#!/bin/bash
basepath=$(cd `dirname $0`; pwd)
#echo $basepath
#carthage build --no-skip-current
carthage build --no-skip-current --platform iOS
#carthage archive
rm -r $basepath/build
#rm -r $basepath/Carthage


